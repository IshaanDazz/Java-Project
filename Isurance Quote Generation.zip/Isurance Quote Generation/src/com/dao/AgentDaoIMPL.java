package com.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.AgentBean;
import com.bean.AgentPolicyCreationBean;
import com.bean.QuestionBean;
import com.bean.AgentViewPolicyBean;
import com.bean.LoginBean;
import com.exception.AgentException;
import com.util.DBConnection;

public class AgentDaoIMPL implements AgentDao {

	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultset = null;
	AgentBean agentBean = null;

	// Agent account creation

	@Override
	public void accountCreation(AgentBean agentBean) throws AgentException, SQLException, IOException {
		connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, agentBean.getAgentName());
			preparedStatement.setString(2, agentBean.getUsername());
			preparedStatement.setString(3, agentBean.getInsuredName());
			preparedStatement.setString(4, agentBean.getInsuredStreet());
			preparedStatement.setString(5, agentBean.getInsuredCity());
			preparedStatement.setString(6, agentBean.getInsuredState());
			preparedStatement.setLong(7, agentBean.getInsuredZip());
			preparedStatement.setLong(8, agentBean.getAccountNumber());
			preparedStatement.setString(9, agentBean.getBusinessSegment());
			preparedStatement.executeQuery();

		} catch (SQLException e) {
			throw new AgentException("Tehnical problem occured. Refer log");
		}

	}

	public boolean findAgentName(String agentName) throws AgentException, SQLException, IOException {
		connection = DBConnection.getConnection();
		String agentName1;
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.FIND_AGENT_NAME);
			preparedStatement.setString(1, agentName);
			resultset = preparedStatement.executeQuery();
			agentName1 = resultset.getString(1);
			if (agentName == agentName1) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {

			throw new AgentException("Tehnical problem occured. Refer log");
		}

	}

	@Override
	public AgentViewPolicyBean getPolicyDetails(String agentName) throws AgentException, SQLException, IOException {

		connection = DBConnection.getConnection();
		AgentViewPolicyBean agentViewPolicyBean = null;

		try {
			agentViewPolicyBean = new AgentViewPolicyBean();
			preparedStatement = connection.prepareStatement(QueryMapper.VIEW_POLICY_DETAILS_QUERY);
			preparedStatement.setString(1, agentName);
			resultset = preparedStatement.executeQuery();

			while (resultset.next()) {

				agentViewPolicyBean.setInsuredName(resultset.getString(1));
				agentViewPolicyBean.setPolicyNumber(resultset.getLong(2));
				agentViewPolicyBean.setPolicyPremium(resultset.getDouble(3));
				agentViewPolicyBean.setAccountNumber(resultset.getLong(4));

			}

			if (agentViewPolicyBean != null) {

				// logger.info("Record Found Successfully");

				return agentViewPolicyBean;
			} else {
				// logger.info("Record Not Found Successfully");
				return null;
			}

		} catch (Exception e) {
			e.printStackTrace();
			// logger.error(e.getMessage());
			throw new AgentException(e.getMessage());
		} finally {
			try {
				// resultset.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// logger.error(e.getMessage());
				throw new AgentException("Error in closing db connection");

			}
		}

	}

	@Override
	public ArrayList<QuestionBean> getQuestionAnswer(QuestionBean questionBean) throws AgentException, IOException {

		AgentPolicyCreationBean agentPolicyCreationBean = new AgentPolicyCreationBean();
		ArrayList<QuestionBean> al = new ArrayList<>();
		try {
			connection = DBConnection.getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.SEARCH_POLICY);
			preparedStatement.setString(1, questionBean.getBusinessSegment());
			preparedStatement.executeQuery();

			while (resultset.next()) {

				questionBean.setQuestion(resultset.getString(1));
				questionBean.setAnswer1(resultset.getString(2));
				questionBean.setAnswer2(resultset.getString(3));
				questionBean.setAnswer3(resultset.getString(4));

			}
		} catch (SQLException e) {

			throw new AgentException("Error in Policy Creation");

		}

		return al;
	}

	@Override
	public void policyCreation(AgentPolicyCreationBean agentPolicyCreationBean)
			throws SQLException, IOException, AgentException {

		connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.CREATE_POLICY);
			preparedStatement.setString(1, agentPolicyCreationBean.getBusinessSegment());
			preparedStatement.setString(2, agentPolicyCreationBean.getQuestion());
			preparedStatement.setString(3, agentPolicyCreationBean.getAnswer());
			preparedStatement.setInt(4, agentPolicyCreationBean.getWeightage());
			preparedStatement.setString(5, agentPolicyCreationBean.getUsername());
			preparedStatement.executeQuery();

		} catch (SQLException e) {
			throw new AgentException("Error in policy creation");
		}
	}

	public String checkUser(LoginBean loginBean) throws AgentException, SQLException, IOException {

		connection = DBConnection.getConnection();
		try {
			preparedStatement = connection.prepareStatement(QueryMapper.FIND_ROLE);
			preparedStatement.setString(1, loginBean.getUserName());
			resultset = preparedStatement.executeQuery();
			String role = resultset.getString(1);
			return role;
		} catch (SQLException e) {

			throw new AgentException("Error in check user");
		}
	}

}
