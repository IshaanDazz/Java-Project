package com.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.bean.AgentBean;
import com.bean.QuestionBean;
import com.bean.AgentViewPolicyBean;
import com.bean.LoginBean;
import com.bean.AgentPolicyCreationBean;
import com.exception.AgentException;
import com.service.AgentService;
import com.service.AgentServiceIMPL;

public class Agent {

	static AgentService agentService=null;
	static QuestionBean questionBean=new QuestionBean();
	static AgentPolicyCreationBean agentPolicyCreationBean=new AgentPolicyCreationBean();
	static Scanner scanner=new Scanner(System.in);
	static AgentServiceIMPL agentServiceIMPL=new AgentServiceIMPL();
	public static void main(String[] args) {
	
		LoginBean loginBean=new LoginBean();
		AgentBean agentBean = null;
		String accountNumber=null;
		System.out.println("Welcome to Insurance Quote Generation Application");
		System.out.println("___________________________________________________\n");
		System.out.println("Enter the Username:");
		loginBean.setUserName(scanner.next());
		System.out.println("Enter the Password");
		loginBean.setPassword(scanner.next());
		String role="";
		try {
			try {
				role=agentServiceIMPL.checkUser(loginBean);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		} catch (AgentException e2) {
			// TODO Auto-generated catch block
			//e2.printStackTrace();
		}
		if(role=="Underwrite" || role=="underwrite")
		{
			
		}
		else if(role=="Agent" || role=="agent")
		{
			while(true)
			{
				System.out.println("______________________\n");
				System.out.println("Welcome Agent");
				System.out.println("______________________\n");
				System.out.println("1. Policy Creation.");
				System.out.println("2. View policy.");
				System.out.println("3. Exit.");
				System.out.println("Enter your choice:");
				try
				{
					int agentChoice=scanner.nextInt();
					switch(agentChoice)
					{
					case 1:
						while(agentBean==null)
						{
							try {
								try {
									agentBean=populateAgentBean();
								} catch (SQLException e) {
									// TODO Auto-generated catch block
									//e.printStackTrace();
								} catch (IOException e) {
									// TODO Auto-generated catch block
									//e.printStackTrace();
								}
							} catch (AgentException e) {
								// TODO Auto-generated catch block
								//e.printStackTrace();
							}
						}
						
						agentService=new AgentServiceIMPL();
						
						try {
							agentService.accountCreation(agentBean);
						} catch (AgentException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
						if(accountNumber==null)
						{
							System.out.println("___________________________\n");
							System.out.println("Account is not created!!");
							System.out.println("Try Again!!");
							System.out.println("___________________________\n");
						}
						else
						{
							System.out.println("___________________________\n");
							System.out.println("Account successfully created.");
							System.out.println("Account number is: "+accountNumber);
							System.out.println("___________________________\n");
							accountNumber=null;
							agentService=null;
							agentBean=null;		
						}
						
						break;
					case 2:
						AgentViewPolicyBean agentViewPolicyBean=new AgentViewPolicyBean();
						System.out.println("Enter your unique agent name:");
						String agentName=scanner.next();
						try {
							
							agentViewPolicyBean=getPolicyDetails(agentName);
							
						} catch (AgentException e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(agentViewPolicyBean!=null)
						{
							System.out.println("Policy Details of your customer");
							System.out.println("___________________________________________________\n");
							System.out.println("Insured Name:"+agentViewPolicyBean.getInsuredName());
							System.out.println("Policy Number: "+agentViewPolicyBean.getPolicyNumber());
							System.out.println("Policy Premium: "+agentViewPolicyBean.getPolicyPremium());
							System.out.println("Account No: "+agentViewPolicyBean.getAccountNumber());
							System.out.println("___________________________________________________\n");
							
						}
						if(agentViewPolicyBean==null)
						{
							System.out.println("___________________________________________________\n");
							System.out.println("Agent Name is invalid!!");
							System.out.println("___________________________________________________\n");
							System.exit(0);
						}
						break;
					case 3:
						System.out.println("Have a good Day!!");
						System.exit(0);
						break;
						default:
							System.out.println("____________________________________\n");
							System.out.println("You have entered a wrong choice!!");
							System.out.println("Try Again!!");
							System.out.println("_____________________________________\n");
							break;
					}
					
					}
					catch(InputMismatchException e)
					{
						System.out.println("___________________________________________\n");
						System.out.println("Please enter a numeric value, Try Again!!");
						System.out.println("____________________________________________\n");
						break;
					}
				}
		}
		else if(role=="User" || role=="user")
		{
			
		}
		else
		{
			System.out.println("You have entered wrong username and password!!");
		}
		
			
		
	}
	private static AgentViewPolicyBean getPolicyDetails(String agentName) throws AgentException, SQLException, IOException {
		AgentViewPolicyBean agentViewPolicyBean=new AgentViewPolicyBean();
		agentService=new AgentServiceIMPL();
		agentViewPolicyBean=agentService.getPolicyDetails(agentName);
		return agentViewPolicyBean ;
	}
	
	private static AgentBean populateAgentBean() throws AgentException, SQLException, IOException {
		AgentBean agentBean=new AgentBean();
		System.out.println("Enter Insured Name:");
		agentBean.setInsuredName(scanner.next());
		System.out.println("Enter Insured Street:");
		agentBean.setInsuredStreet(scanner.next());
		System.out.println("Enter Insured City:");
		agentBean.setInsuredCity(scanner.next());
		System.out.println("Enter Insured State:");
	    agentBean.setInsuredState(scanner.next());
		System.out.println("Enter Insured Zip:");
		agentBean.setInsuredZip(scanner.nextLong());
		
		
		System.out.println("Choose Your Business Segment:");
		System.out.println("1. Business Auto.");
		System.out.println("2. Restaurant.");
		System.out.println("3. Apartment.");
		System.out.println("4. General Marchant.");
		System.out.println("Enter your choice:");
		int businessSegmentChoice=scanner.nextInt();
		switch(businessSegmentChoice)
		{
		case 1:
			agentBean.setBusinessSegment("Business Auto");
			questionBean.setBusinessSegment("Business Auto");
			ArrayList<QuestionBean> al = new ArrayList<>();
			al = agentService.getQuestionAnswer(questionBean);
			System.out.println("You have to answer all the Policy Creation Quenstions:");
			
			for( QuestionBean questionBean:al) {
				
				
				System.out.println("_____________________________________________________________________________________________________________________________________\n");
				System.out.println(questionBean.getQuestion());
				System.out.println("1."+questionBean.getAnswer1()+"\t"+"2."+questionBean.getAnswer2()+"\t"+"3."+questionBean.getAnswer3());
				System.out.println("______________________________________________________________________________________________________________________________________\n");
				System.out.println("Enter the option:");
				int option=scanner.nextInt();
				switch(option) {
				case 1:
					long premium=0;
					agentPolicyCreationBean.setBusinessSegment("Business Auto");
					agentPolicyCreationBean.setAnswer(questionBean.getAnswer1());
					agentPolicyCreationBean.setWeightage(questionBean.getWeightage1());
					System.out.println("Enter the unique user name of the user: ");
					agentPolicyCreationBean.setUsername(scanner.next());
					agentService.policyCreation(agentPolicyCreationBean);
					
					break;
				case 2:
					agentPolicyCreationBean.setAnswer(questionBean.getAnswer2());
					agentPolicyCreationBean.setWeightage(questionBean.getWeightage2());
					
					break;
				case 3:
					agentPolicyCreationBean.setAnswer(questionBean.getAnswer3());
					agentPolicyCreationBean.setWeightage(questionBean.getWeightage3());
					
				}
			}
			break;
		case 2:
			agentBean.setBusinessSegment("Restaurant");
			break;
		case 3:
			agentBean.setBusinessSegment("Apartment");
			break;
		case 4:
			agentBean.setBusinessSegment("General Marchant");
			break;
			default:
				System.out.println("You have entered a wrong choice!!");
				System.exit(0);
				break;
		}
		System.out.println("Enter your account no:");
		agentBean.setAccountNumber(scanner.nextLong());
		
		System.out.println("Enter you unique Agent user name:");
		agentBean.setAgentName(scanner.next());
		
		
		agentServiceIMPL.validateAgent(agentBean);
		return agentBean;
		
	}
}
