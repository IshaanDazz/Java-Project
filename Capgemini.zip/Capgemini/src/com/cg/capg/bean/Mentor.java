package com.cg.capg.bean;

public class Mentor {

	private int labNo;
	private int empIdOfTrainee;
	private String mailIdOfTrainee;
	private String nameOfTrainee;
	private long contactNoOfTrainee;
	private String courseName;
	private int empIdOfTrainer;
	private String nameOfTrainer;
	private int assignmentId;
	private String assignmentName;
	private String courseName1;
	private long contactNoOfTrainer;
	private String courseName2;
	private String courseName3;
	
	public String getCourseName3() {
		return courseName3;
	}
	public void setCourseName3(String courseName3) {
		this.courseName3 = courseName3;
	}
	public String getCourseName2() {
		return courseName2;
	}
	public void setCourseName2(String courseName2) {
		this.courseName2 = courseName2;
	}
	public long getContactNoOfTrainer() {
		return contactNoOfTrainer;
	}
	public void setContactNoOfTrainer(long contactNoOfTrainer) {
		this.contactNoOfTrainer = contactNoOfTrainer;
	}
	public String getCourseName1() {
		return courseName1;
	}
	public void setCourseName1(String courseName1) {
		this.courseName1 = courseName1;
	}
	public int getLabNo() {
		return labNo;
	}
	public void setLabNo(int labNo) {
		this.labNo = labNo;
	}
	public int getEmpIdOfTrainee() {
		return empIdOfTrainee;
	}
	public void setEmpIdOfTrainee(int empIdOfTrainee) {
		this.empIdOfTrainee = empIdOfTrainee;
	}
	public String getMailIdOfTrainee() {
		return mailIdOfTrainee;
	}
	public void setMailIdOfTrainee(String mailIdOfTrainee) {
		this.mailIdOfTrainee = mailIdOfTrainee;
	}
	public String getNameOfTrainee() {
		return nameOfTrainee;
	}
	public void setNameOfTrainee(String nameOfTrainee) {
		this.nameOfTrainee = nameOfTrainee;
	}
	public long getContactNoOfTrainee() {
		return contactNoOfTrainee;
	}
	public void setContactNoOfTrainee(long contactNoOfTrainee) {
		this.contactNoOfTrainee = contactNoOfTrainee;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getEmpIdOfTrainer() {
		return empIdOfTrainer;
	}
	public void setEmpIdOfTrainer(int empIdOfTrainer) {
		this.empIdOfTrainer = empIdOfTrainer;
	}
	public String getNameOfTrainer() {
		return nameOfTrainer;
	}
	public void setNameOfTrainer(String nameOfTrainer) {
		this.nameOfTrainer = nameOfTrainer;
	}
	public int getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(int assignmentId) {
		this.assignmentId = assignmentId;
	}
	public String getAssignmentName() {
		return assignmentName;
	}
	public void setAssignmentName(String assignmentName) {
		this.assignmentName = assignmentName;
	}
	@Override
	public String toString() {
		return "Mentor [labNo=" + labNo + ", empIdOfTrainee=" + empIdOfTrainee + ", mailIdOfTrainee=" + mailIdOfTrainee
				+ ", nameOfTrainee=" + nameOfTrainee + ", contactNoOfTrainee=" + contactNoOfTrainee + ", courseName="
				+ courseName + ", empIdOfTrainer=" + empIdOfTrainer + ", nameOfTrainer=" + nameOfTrainer
				+ ", assignmentId=" + assignmentId + ", assignmentName=" + assignmentName + "]";
	}
	
	
	
}
