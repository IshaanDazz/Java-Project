package com.cg.capg.pl;

import java.io.IOException;
import java.util.Scanner;

import com.cg.capg.bean.Mentor;
import com.cg.capg.bean.Trainee;
import com.cg.capg.exception.CapgeminiException;
import com.cg.capg.service.Choice;
import com.cg.capg.service.MentorService;
import com.cg.capg.service.MentorServiceIMPL;
import com.cg.capg.service.MentorValidation;
import com.cg.capg.service.TraineeService;
import com.cg.capg.service.TraineeServiceIMPL;
import com.cg.capg.service.TraineeValidation;

public class CapgeminiMain {

	static Scanner scanner=new Scanner(System.in);
	static MentorService mentorService=null;
	static TraineeService traineeService=null;
	public static void main(String[] args) throws CapgeminiException, IOException {
		
		Mentor mentor=null;
		Trainee trainee=null;
		System.out.println("WELCOME TO CAPGEMINI ASSIGNMENT PORTAL");
		System.out.println("_______________________________________\n");
		System.out.println("Who are you?");
		System.out.println("1.Mentor.");
		System.out.println("2.Trainee.");
		System.out.println("3.Exit.");
		System.out.println("Enter your choice:");
		int choice=scanner.nextInt();
		Choice ch= new Choice();
		MentorValidation mentorValidation=new MentorValidation();
		TraineeValidation traineeValidation=new TraineeValidation();
		while(ch.choice(choice)!=true)
		{
			System.err.println("You have entered wrong choice!!");
			System.out.println("Enter right choice:");
			choice=scanner.nextInt();
			ch.choice(choice);
		}
		if(ch.choice(choice)==true)
		{
			
				switch(choice)
				{
				case 1:
					System.out.println("Enter your name:");
					String name=scanner.next();
					while(mentorValidation.mentorName(name)!=true)
					{
						System.err.println("You have entered your name incorrectly!!");
						System.out.println("Name should be start with captital letter & not be greater than 20 characters.");
						System.out.println("Enter your name:");
						name=scanner.next();
						mentorValidation.mentorName(name);
					}
					System.out.println("Enter your id:");
					int id=scanner.nextInt();
					while(mentorValidation.mentorId(id)!=true)
					{
						System.err.println("You have entered your id incorrectly!!");
						System.out.println("Employee Id should be only 6 number & should not start with 0.");
						System.out.println("Enter your id:");
						id=scanner.nextInt();
						mentorValidation.mentorId(id);
					}
					while(true)
					{
						System.out.println("What do you want to do?");
						System.out.println("1.Add Candidate.");
						System.out.println("2.Add trainer.");
						System.out.println("3.Add assignment.");
						System.out.println("4.Delete assignment.");
						System.out.println("5.Exit.");
						System.out.println("________________________\n");
						System.out.println("Enter your choice:");
						
						int choice1=scanner.nextInt();
						while(ch.choice1(choice1)!=true)
						{
							System.err.println("You have entered wrong choice!!");
							System.out.println("Enter right choice:");
							choice1=scanner.nextInt();
							ch.choice1(choice1);
						}
						if(ch.choice1(choice1)==true)
						{
							switch(choice1)
							{
							case 1:
								while(mentor==null)
								{
									mentor=populatedMentor();
									
								}
								try {
									mentorService=new MentorServiceIMPL();
								  //  mentorService.addCandidate(mentor);
								    System.out.println("Trainee successfully entered.");
								}
								finally
								{
									mentor=null;
									mentorService=null;
								}
								break;
							case 2:
								while(mentor==null)
								{
									mentor=populatedMentor1();
								}
								try {
									mentorService=new MentorServiceIMPL();
								   // mentorService.addTrainer(mentor);
								    System.out.println("Trainer successfully entered.");
								}
								finally
								{
									mentor=null;
									mentorService=null;
								}
								break;
							case 3:
								while(mentor==null)
								{
									mentor=populatedMentor2();
								}
								try {
									mentorService=new MentorServiceIMPL();
								  //  mentorService.addAssignment(mentor);
								    System.out.println("Assignment successfully entered.");
								}
								finally
								{
									mentor=null;
									mentorService=null;
								}
								break;
							case 4:
								while(mentor==null)
								{
									mentor=populatedMentor3();
								}
								try {
									//mentorService=new MentorServiceIMPL();
								    //mentorService.deleteAssignment(mentor);
								    System.out.println("Assignment successfully deleted.\n");
								}
								finally
								{
									mentor=null;
									mentorService=null;
								}
								break;
							case 5:
								System.exit(0);
									break;
							}
					
						}
						
					}
				case 2:
					System.out.println("Enter your name:");
					String name3=scanner.next();
					while(traineeValidation.traineeName(name3)!=true)
					{
						System.err.println("You have entered your name incorrectly!!");
						System.out.println("Name should be start with captital letter & not be greater than 20 characters.");
						System.out.println("Enter your name:");
						name3=scanner.next();
						traineeValidation.traineeName(name3);
					}
					System.out.println("Enter your id:");
					int id1=scanner.nextInt();
					while(traineeValidation.traineeId(id1)!=true)
					{
						System.err.println("You have entered your id incorrectly!!");
						System.out.println("Employee Id should be only 6 number & should not start with 0.");
						System.out.println("Enter your id:");
						id1=scanner.nextInt();
						traineeValidation.traineeId(id1);
					}
					while(true)
					{
						System.out.println("What do you want to do?");
						System.out.println("1.View assignment.");
						System.out.println("2.view trainer details.");
						System.out.println("3.Exit.");
						System.out.println("________________________\n");
						System.out.println("Enter your choice:");
						int choice2=scanner.nextInt();
						while(ch.choice2(choice2)!=true)
						{
							System.err.println("You have entered wrong choice!!");
							System.out.println("Enter right choice:");
							choice2=scanner.nextInt();
							ch.choice2(choice2);
						}
						if(ch.choice2(choice2)==true)
						{
							switch(choice2)
							{
							case 1:
								while(trainee==null)
								{
									trainee=populatedTrainee();
									
								}
								try {
									traineeService=new TraineeServiceIMPL();
								    //traineeService.viewAssignments(trainee);
								   
								}
								finally
								{
									trainee=null;
									traineeService=null;
								}
								
								break;
							case 2:
								while(trainee==null)
								{
									trainee=populatedTrainee1();
									
								}
								try {
									traineeService=new TraineeServiceIMPL();
								   // traineeService.viewTrainerDetails(trainee);
								   
								}
								finally
								{
									trainee=null;
									traineeService=null;
								}
								break;
							case 3:
								System.exit(0);
								break;
							}
						}
					}
				case 3:
					System.exit(0);
						break;
						
				}
		}
		
		
	}
	private static Mentor populatedMentor3() throws CapgeminiException, IOException {
		Mentor mentor= new Mentor();
		
		 System.out.println("Enter the course name:");
		 mentor.setCourseName3(scanner.next());
		 MentorServiceIMPL mentorServiceIMPL=new MentorServiceIMPL();
		 try {
			 mentorServiceIMPL.validateCourse(mentor);
			 mentorService=new MentorServiceIMPL();
			 mentorService.deleteAssignment(mentor);
		 }
		catch(CapgeminiException e)
		 {
			System.err.println(e);
		 }
		 
		 return mentor;
	}
	private static Trainee populatedTrainee1() throws IOException, CapgeminiException {
		Trainee trainee= new Trainee();
		
		 System.out.println("Enter the course name:");
		 trainee.setCourseName(scanner.next());
		 
		 traineeService=new TraineeServiceIMPL();
		 TraineeServiceIMPL traineeServiceIMPL=new TraineeServiceIMPL();
		 traineeServiceIMPL.validateTrainerDetails(trainee);
		 traineeService.viewTrainerDetails(trainee);
		
		 return trainee;
	}
	private static Trainee populatedTrainee() throws CapgeminiException, IOException {
		Trainee trainee= new Trainee();
		
		 System.out.println("Enter the course name:");
		 trainee.setCourseName(scanner.next());
		 
		 traineeService=new TraineeServiceIMPL();
		 TraineeServiceIMPL traineeServiceIMPL=new TraineeServiceIMPL();
		 traineeServiceIMPL.validateAssignment(trainee);
		 traineeService.viewAssignments(trainee);
		
		 return trainee;
		
	}
	private static Mentor populatedMentor2() throws IOException {
		 Mentor mentor= new Mentor();
		 System.out.println("Enter details:");
		 System.out.println("_______________\n");
		 
		 System.out.println("Enter name of the assignment:");
		 mentor.setAssignmentName(scanner.next());
		 
		 System.out.println("Enter the assignment id:");
		 mentor.setAssignmentId(scanner.nextInt());
	
		 System.out.println("Enter the course name of the assignment:");
		 mentor.setCourseName2(scanner.next());
		 
		 mentorService=new MentorServiceIMPL();
		 MentorServiceIMPL mentorServiceIMPL=new MentorServiceIMPL();
		 try {
			 mentorServiceIMPL.validateAssignment(mentor);
			 mentorService.addAssignment(mentor);
			 return mentor;
		 }
		 catch(CapgeminiException e)
		 {
			 System.err.println("Error: "+e);
		 }
		return null;
	}
	private static Mentor populatedMentor1() throws IOException {
		 Mentor mentor= new Mentor();
		 System.out.println("Enter details:");
		 System.out.println("_______________\n");
		 
		 System.out.println("Enter name of the trainer:");
		 mentor.setNameOfTrainer(scanner.next());
		 
		 System.out.println("Enter the employee id of the trainer:");
		 mentor.setEmpIdOfTrainer(scanner.nextInt());
		 
		 System.out.println("Enter contact number of the employee:");
		 mentor.setContactNoOfTrainer(scanner.nextLong());
		 
		 System.out.println("Enter the course name of the trainer:");
		 mentor.setCourseName1(scanner.next());
		 
		 mentorService=new MentorServiceIMPL();
		 MentorServiceIMPL mentorServiceIMPL=new MentorServiceIMPL();
		 try {
			 mentorServiceIMPL.validateTrainer(mentor);
			 mentorService.addTrainer(mentor);
			 return mentor;
		 }
		 catch(CapgeminiException e)
		 {
			 System.err.println("Error: "+e);
		 }
		return null;
	}
	private static Mentor populatedMentor() throws IOException {
		
		 Mentor mentor= new Mentor();
		
		 System.out.println("Enter details:");
		 System.out.println("______________\n");
		 
		 System.out.println("Enter name of the trainee:");
		 mentor.setNameOfTrainee(scanner.next());
		 
		 System.out.println("Enter id of the trainee:");
		 mentor.setEmpIdOfTrainee(scanner.nextInt());
		 
		 System.out.println("Enter mail id of the trainee:");
		 mentor.setMailIdOfTrainee(scanner.next());
		 
		 System.out.println("Enter contact number of the trainee:");
		 mentor.setContactNoOfTrainee(scanner.nextLong());
		 
		 System.out.println("Enter lab number of the trainee: ");
		 mentor.setLabNo(scanner.nextInt());
		 
		 System.out.println("Enter course name for the trainee:");
		 mentor.setCourseName(scanner.next());
		 
		 mentorService=new MentorServiceIMPL();
		 MentorServiceIMPL mentorServiceIMPL=new MentorServiceIMPL();
		 try {
			 mentorServiceIMPL.validateTrainee(mentor);
			 mentorService.addCandidate(mentor);
			 return mentor;
		 }
		 catch(CapgeminiException e)
		 {
			 System.err.println("Error: "+e);
		 }
		return null;
		
	}
}
