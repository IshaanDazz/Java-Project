package com.cg.capg.exception;

public class CapgeminiException extends Exception {

	public CapgeminiException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
