package com.cg.capg.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.capg.bean.Mentor;
import com.cg.capg.dao.MentorDao;
import com.cg.capg.dao.MentorDaoIMPL;
import com.cg.capg.exception.CapgeminiException;

public class MentorServiceIMPL implements MentorService {

	MentorDao mentorDao= new MentorDaoIMPL();
	
	
	@Override
	public void addCandidate(Mentor mentor) throws CapgeminiException, IOException {
		
		mentorDao.addCandidate(mentor);
	
		
	}
	@Override
	public void addTrainer(Mentor mentor) throws CapgeminiException, IOException{
		mentorDao.addTrainer(mentor);
		
	}

	@Override
	public void addAssignment(Mentor mentor) throws CapgeminiException, IOException {
		mentorDao.addAssignment(mentor);
		
	}

	@Override
	public void deleteAssignment(Mentor mentor) throws CapgeminiException, IOException {
		mentorDao.deleteAssignment(mentor);
		
	}

	
	public void validateCourse(Mentor mentor) throws CapgeminiException
	{
		List<String> list=new ArrayList<>();
		boolean result=false;
		if(!isCourseNameValid(mentor.getCourseName3()))
	    {
			list.add("Course name should be start with captital letter & not be greater than 10 characters.");
		}
	}
	private boolean isCourseNameValid(String courseName3) {
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,9}");
		Matcher matcher=pattern.matcher(courseName3);
		return matcher.matches();
	}
	public void validateTrainee(Mentor mentor) throws CapgeminiException
	{

		List<String> list=new ArrayList<>();
		boolean result=false;
		if(!isNameValid(mentor.getNameOfTrainee()))
	    {
			list.add("Name should be start with captital letter & not be greater than 20 characters.");
		}
		if(!isEmpId(mentor.getEmpIdOfTrainee()))
		{
			list.add("Employee Id should be only 6 number & should not start with 0.");
		}
		if(!isMailId(mentor.getMailIdOfTrainee()))
		{
			list.add("Mail id of the trainee should contain @capgemini.com & also give a '.' between your first name and last name");
		}
		if(!isLabNo(mentor.getLabNo()))
		{
			list.add("Lab no should be with in 1 to 9");
		}
		if(!isContactNo(mentor.getContactNoOfTrainee()))
		{
			list.add("Contact no of trainee should contain 10 didgits only & should start with 6 to 9.");
		}
		if(!isCourseName(mentor.getCourseName()))
		{
			list.add("Course name should start with capital letter & not be greater than 10 characters.");
		}
		if(!list.isEmpty())
		{
			throw new CapgeminiException(list+"");
		}
	}
	public void validateTrainer(Mentor mentor) throws CapgeminiException
	{

		List<String> list=new ArrayList<>();
		boolean result=false;
		if(!isNameValid1(mentor.getNameOfTrainer()))
	    {
			list.add("Name should be start with captital letter & not be greater than 20 characters.");
		}
		if(!isEmpId1(mentor.getEmpIdOfTrainer()))
		{
			list.add("Employee Id should be only 6 number & should not start with 0.");
		}
		if(!isContactNo1(mentor.getContactNoOfTrainer()))
		{
			list.add("Contact no of trainer should contain 10 didgits only & should start with 6 to 9.");
		}
		if(!isCourseName1(mentor.getCourseName1()))
		{
			list.add("Course name should start with capital letter & not be greater than 10 characters.");
		}
		if(!list.isEmpty())
		{
			throw new CapgeminiException(list+"");
		}
	}
	public void validateAssignment(Mentor mentor) throws CapgeminiException
	{

		List<String> list=new ArrayList<>();
		boolean result=false;
		if(!isNameValid2(mentor.getAssignmentName()))
	    {
			list.add("Name should be start with captital letter & not be greater than 20 characters.");
		}
		if(!isAssignmentId2(mentor.getAssignmentId()))
		{
			list.add("Employee Id should be only 3 number & should not start with 0.");
		}
		if(!isCourseName2(mentor.getCourseName2()))
		{
			list.add("Course name should start with capital letter & not be greater than 10 characters.");
		}
		if(!list.isEmpty())
		{
			throw new CapgeminiException(list+"");
		}
	}
	private boolean isNameValid2(String assignmentName) {
		
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher matcher=pattern.matcher(assignmentName);
		return matcher.matches();
	}
	private boolean isAssignmentId2(int assignmentId) {
		Pattern pattern=Pattern.compile("[1-9][0-9]{2}");
		Matcher matcher=pattern.matcher(String.valueOf(assignmentId));
		return matcher.matches();
	}
	private boolean isCourseName2(String courseName2) {
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,9}");
		Matcher matcher=pattern.matcher(courseName2);
		return matcher.matches();
	}
	private boolean isNameValid1(String nameOfTrainer) {
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher matcher=pattern.matcher(nameOfTrainer);
		return matcher.matches();
	}
	private boolean isEmpId1(int empIdOfTrainer) {
		Pattern pattern=Pattern.compile("[1-9][0-9]{5}");
		Matcher matcher=pattern.matcher(String.valueOf(empIdOfTrainer));
		return matcher.matches();
	}
	private boolean isContactNo1(long contactNoOfTrainer) {
		Pattern pattern=Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher=pattern.matcher(String.valueOf(contactNoOfTrainer));
		return matcher.matches();
	}
	private boolean isCourseName1(String courseName1) {
		
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,9}");
		Matcher matcher=pattern.matcher(courseName1);
		return matcher.matches();
	}
	private boolean isNameValid(String nameOfTrainee) {
		
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher matcher=pattern.matcher(nameOfTrainee);
		return matcher.matches();
	}

	private boolean isEmpId(int empIdOfTrainee) {
		

		Pattern pattern=Pattern.compile("[1-9][0-9]{5}");
		Matcher matcher=pattern.matcher(String.valueOf(empIdOfTrainee));
		return matcher.matches();
	}
	

	private boolean isMailId(String mailIdOfTrainee) {
		
		Pattern pattern=Pattern.compile("[a-z]*[.][a-z]*@capgemini.com");
		Matcher matcher=pattern.matcher(mailIdOfTrainee);
		return matcher.matches();
	}
	
	private boolean isLabNo(int labNo) {
		
		Pattern pattern=Pattern.compile("[1-9]{1,2}");
		Matcher matcher=pattern.matcher(String.valueOf(labNo));
		return matcher.matches();
		
	}
	

	private boolean isContactNo(long contactNoOfTrainee) {
		
		Pattern pattern=Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher=pattern.matcher(String.valueOf(contactNoOfTrainee));
		return matcher.matches();
	}


	private boolean isCourseName(String courseName) {
		
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,9}");
		Matcher matcher=pattern.matcher(courseName);
		return matcher.matches();
	}
	
	
}
