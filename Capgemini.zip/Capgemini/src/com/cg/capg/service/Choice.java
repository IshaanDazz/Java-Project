package com.cg.capg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Choice {

	public boolean choice;

	public boolean choice(int choice)
	{
		Pattern pattern=Pattern.compile("[1-3]");
		Matcher matcher=pattern.matcher(String.valueOf(choice));
		//System.out.println(matcher.matches());
		return matcher.matches();
	}
	public boolean choice1(int choice)
	{

		Pattern pattern=Pattern.compile("[1-5]");
		Matcher matcher=pattern.matcher(String.valueOf(choice));
		//System.out.println(matcher.matches());
		return matcher.matches();
	}
	public boolean choice2(int choice)
	{

		Pattern pattern=Pattern.compile("[1-3]");
		Matcher matcher=pattern.matcher(String.valueOf(choice));
		//System.out.println(matcher.matches());
		return matcher.matches();
	}
}
