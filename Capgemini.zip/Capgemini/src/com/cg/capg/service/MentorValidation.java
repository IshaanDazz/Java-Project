package com.cg.capg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MentorValidation{

	public boolean mentorName(String name) {
		
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher matcher=pattern.matcher(String.valueOf(name));
		//System.out.println(matcher.matches());
		return matcher.matches();
	}
	public boolean mentorId(int id) {
		
		Pattern pattern=Pattern.compile("[1-9][0-9]{5}");
		Matcher matcher=pattern.matcher(String.valueOf(id));
		//System.out.println(matcher.matches());
		return matcher.matches();
	}

}
