package com.cg.capg.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.capg.bean.Mentor;
import com.cg.capg.bean.Trainee;
import com.cg.capg.dao.MentorDao;
import com.cg.capg.dao.MentorDaoIMPL;
import com.cg.capg.dao.TraineeDao;
import com.cg.capg.dao.TraineeDaoIMPL;
import com.cg.capg.exception.CapgeminiException;

public class TraineeServiceIMPL implements TraineeService{

	TraineeDao traineeDao= new TraineeDaoIMPL();
	@Override
	public void viewTrainerDetails(Trainee trainee) throws IOException {
		traineeDao.viewTrainerDetails(trainee);
	}
	public void validateTrainerDetails(Trainee trainee) throws CapgeminiException 
	{
		List<String> list=new ArrayList<>();
		boolean result=false;
		if(!isNameValid(trainee.getCourseName()))
	    {
			list.add("Course name should be start with captital letter & not be greater than 10 characters.");
		}
		if(!list.isEmpty())
		{
			throw new CapgeminiException(list+"");
		}
	}

	@Override
	public void viewAssignments(Trainee trainee) throws IOException {
		traineeDao.viewAssignments(trainee);
	}
	public void validateAssignment(Trainee trainee) throws CapgeminiException 
	{
		List<String> list=new ArrayList<>();
		boolean result=false;
		if(!isNameValid(trainee.getCourseName()))
	    {
			list.add("Course name should be start with captital letter & not be greater than 10 characters.");
		}
		if(!list.isEmpty())
		{
			throw new CapgeminiException(list+"");
		}
	}

	private boolean isNameValid(String courseName) {
		Pattern pattern=Pattern.compile("[A-Z][a-z]{1,9}");
		Matcher matcher=pattern.matcher(courseName);
		return matcher.matches();
		
	}
}
