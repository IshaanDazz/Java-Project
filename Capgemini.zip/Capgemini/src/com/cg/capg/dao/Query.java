package com.cg.capg.dao;

public interface Query {

	public static final String select_assignment="select distinct(name),contactno from add_trainer where coursename=?";
	public static final String select_trainer_details="select distinct(name) from add_assignment where coursename=?";
	public static final String insert_candidate="insert into add_candidate values(?,?,?,?,?,?)";
	public static final String insert_trainer="insert into add_trainer values(?,?,?,?)";
	public static final String insert_assignment="insert into add_assignment values(?,?,?)";
	public static final String delete_assignment="delete from add_assignment where coursename=?";
}
