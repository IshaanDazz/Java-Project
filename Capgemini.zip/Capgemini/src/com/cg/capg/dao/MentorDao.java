package com.cg.capg.dao;

import java.io.IOException;

import com.cg.capg.bean.Mentor;
import com.cg.capg.exception.CapgeminiException;

public interface MentorDao {

	void addCandidate(Mentor mentor) throws CapgeminiException, IOException ;
	void addTrainer(Mentor mentor) throws CapgeminiException, IOException;
	void addAssignment(Mentor mentor) throws CapgeminiException, IOException;
	void deleteAssignment(Mentor mentor) throws CapgeminiException, IOException;
	//void updateAssignment() throws CapgeminiException;
}
