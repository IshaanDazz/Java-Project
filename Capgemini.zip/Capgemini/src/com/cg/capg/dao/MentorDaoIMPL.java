package com.cg.capg.dao;


import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.capg.bean.Mentor;
import com.cg.capg.exception.CapgeminiException;
import com.cg.capg.util.DBConnection;

public class MentorDaoIMPL implements MentorDao {

	@Override
	public void addCandidate(Mentor mentor) throws CapgeminiException, IOException{
		//System.out.println("DAO entered");
		Connection con=DBConnection.getconnection();
		//System.out.println("connected");
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=con.prepareStatement(Query.insert_candidate);
			ps.setString(1, mentor.getNameOfTrainee());
			ps.setInt(2, mentor.getEmpIdOfTrainee());
			ps.setString(3, mentor.getMailIdOfTrainee());
			ps.setLong(4, mentor.getContactNoOfTrainee());
			ps.setInt(5, mentor.getLabNo());
			ps.setString(6, mentor.getCourseName());
			ps.executeUpdate();
			con.close();
			ps.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

	@Override
	public void addTrainer(Mentor mentor) throws IOException {
		//System.out.println("DAO entered");
				Connection con=DBConnection.getconnection();
				//System.out.println("connected");
				PreparedStatement ps=null;
				ResultSet rs=null;
				try
				{
					ps=con.prepareStatement(Query.insert_trainer);
					ps.setString(1, mentor.getNameOfTrainer());
					ps.setInt(2, mentor.getEmpIdOfTrainer());
					ps.setLong(3, mentor.getContactNoOfTrainer());
					ps.setString(4, mentor.getCourseName1());
					ps.executeUpdate();
					con.close();
					ps.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
	}

	@Override
	public void addAssignment(Mentor mentor) throws IOException {
		
		//System.out.println("DAO entered");
		Connection con=DBConnection.getconnection();
		//System.out.println("connected");
		PreparedStatement ps=null;
		
		try
		{
			ps=con.prepareStatement(Query.insert_assignment);
			ps.setString(1, mentor.getAssignmentName());
			ps.setInt(2, mentor.getAssignmentId());
			ps.setString(3, mentor.getCourseName2());
			ps.executeUpdate();
			con.close();
			ps.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	@Override
	public void deleteAssignment(Mentor mentor) throws IOException {
		
		//System.out.println("DAO entered");
				Connection con=DBConnection.getconnection();
				//System.out.println("connected");
				PreparedStatement ps=null;
				
				try
				{
					ps=con.prepareStatement(Query.delete_assignment);
					ps.setString(1, mentor.getCourseName3());
					
					ps.executeUpdate();
					ps.close();
					con.close();
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
	}



}
