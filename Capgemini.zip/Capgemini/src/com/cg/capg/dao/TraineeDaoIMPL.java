package com.cg.capg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.cg.capg.bean.Trainee;
import com.cg.capg.util.DBConnection;

public class TraineeDaoIMPL implements TraineeDao{

	@Override
	public void viewTrainerDetails(Trainee trainee) throws IOException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getconnection();
		//System.out.println("connected");
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=con.prepareStatement(Query.select_trainer_details);
			ps.setString(1, trainee.getCourseName());
			rs=ps.executeQuery();
			rs.next();
		
				System.out.println("Trainer Name: "+rs.getString(1));
				System.out.println("Trainer's contact number: "+rs.getLong(2));
			
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}


	@Override
	public void viewAssignments(Trainee trainee) throws IOException {
		Connection con=DBConnection.getconnection();
		//System.out.println("connected");
		PreparedStatement ps=null;
		ResultSet rs=null;
		try
		{
			ps=con.prepareStatement(Query.select_assignment);
			ps.setString(1, trainee.getCourseName());
			rs=ps.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString(1));
			}
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}
