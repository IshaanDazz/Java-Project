package com.cg.capg.dao;

import java.io.IOException;

import com.cg.capg.bean.Trainee;

public interface TraineeDao {

	void viewAssignments(Trainee trainee) throws IOException;
	void viewTrainerDetails(Trainee trainee) throws IOException;
}
