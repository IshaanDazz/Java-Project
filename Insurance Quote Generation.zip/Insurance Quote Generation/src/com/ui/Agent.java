package com.ui;
import java.util.*;

import com.bean.AgentBean;
public class Agent {

	static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		
		AgentBean agentBean = new AgentBean();
		while(true)
		{
			System.out.println("______________________\n");
			System.out.println("Welcome Agent");
			System.out.println("______________________\n");
			System.out.println("1. Account Creation.");
			System.out.println("2. Policy Creation.");
			System.out.println("3. View policy.");
			System.out.println("4. Exit.");
			System.out.println("Enter your choice:");
			try
			{
				int agentChoice=scanner.nextInt();
				switch(agentChoice)
				{
				case 1:
					while(agentBean==null)
					{
						agentBean=populateAgentBean();
					}
					
					break;
				case 2:
					break;
				case 3:
					break;
				case 4:
					System.out.println("Have a good Day!!");
					System.exit(0);
					break;
					default:
						System.out.println("____________________________________\n");
						System.out.println("You have entered a wrong choice!!");
						System.out.println("Try Again!!");
						System.out.println("_____________________________________\n");
						break;
			}
			
			}
			catch(InputMismatchException e)
			{
				System.out.println("___________________________________________\n");
				System.out.println("Please enter a numeric value, Try Again!!");
				System.out.println("____________________________________________\n");
			}
		}
	}
	private static AgentBean populateAgentBean() {
		AgentBean agentBean=new AgentBean();
		System.out.println("Enter Insured Name:");
		agentBean.setInsuredName(scanner.next());
		System.out.println("Enter Insured Street:");
		agentBean.setInsuredStreet(scanner.next());
		System.out.println("Enter Insured City:");
		agentBean.setInsuredCity(scanner.next());
		System.out.println("Enter Insured State:");
		agentBean.setInsuredState(scanner.next());
		System.out.println("Enter Insured Zip:");
		agentBean.setInsuredZip(scanner.nextLong());
		System.out.println("Enter Business Segment:");
		agentBean.setBusinessSegment(scanner.next());
		System.out.println("Enter Insured Accoun Number:");
		agentBean.setAccountNumber(scanner.nextLong());
		
		return null;
	}
}
