package com.capgemini.salesmanagement.ui;
import java.util.*;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.exception.ProductException;
import com.capgemini.salesmanagement.service.IProductService;
import com.capgemini.salesmanagement.service.ProductService;
public class Client {
	static IProductService service=null;
	static Scanner scanner=new Scanner(System.in);
	static ProductService service1=null;
	public static void main(String[] args) {
		ProductBean productBean=new ProductBean();
		while(true)
		{
			System.out.println("Billing Software Application");
			System.out.println("_____________________________\n");
			System.out.println("1.Generate Bill");
			System.out.println("2.Exit");
			System.out.println("Enter your choice:");
			try
			{
				int choice=scanner.nextInt();
				switch(choice)
				{
				case 1:
					
					System.out.println("Enter the product code:");
					int productCode=scanner.nextInt();
					if(!service1.validateProductCode(productCode))
					{
						System.err.println("Invalid product code!!\n");
						System.out.println("Enter correctly:");
						productCode=scanner.nextInt();
					}
					System.out.println("Enter the quantity:");
					int quantity=scanner.nextInt();
					if(!service1.validateQuantity(quantity))
					{
						System.err.println("Invalid quantity!!");
						System.out.println("Enter correctly:");
						quantity=scanner.nextInt();
					}
					try {
						productBean=getProductDetails(productCode);
						if(productBean!=null)
						{
							System.out.println("Product Name:"+productBean.getProductName());
							System.out.println("Product Catagory: "+productBean.getProductCatagory());
							System.out.println("Product Description: "+productBean.getProductDescription());
							System.out.println("Product Price: "+productBean.getProductPrice());
							System.out.println("Line Total: "+(quantity*productBean.getProductPrice()));
						}
					} catch (ProductException e) {
						
						System.err.println("ERROR: "+e.getMessage());
					}
					
					
					break;
				case 2:
					break;
					default:
						break;
				}
			}catch(InputMismatchException e)
			{
				System.err.println("Enter a valid choiice!! Try Again!!");
				System.exit(0);
			}
		}
	}
	private static ProductBean getProductDetails(int productCode)throws ProductException {
		ProductBean productBean=null;
		service1=new ProductService();
		productBean=service1.getProductDetails(productCode);
		service1=null;
		return productBean;
	}
	
}
