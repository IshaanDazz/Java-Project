package com.capgemini.salesmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.IPoductDao;
import com.capgemini.salesmanagement.dao.ProductDao;

public class ProductService implements IProductService{

	IPoductDao dao=null;
	@Override
	public ProductBean getProductDetails(int productCode) {
		dao= new ProductDao();
		ProductBean productBean=null;
		productBean=dao.getProductDetails(productCode);
		return productBean;
		
	}

	@Override
	public boolean insertSalesDetails(ProductBean productBean) {
		
		return false;
	}

	public boolean validateProductCode(int product_code)
	{
		Pattern pattern=Pattern.compile("[1][1-9]{3}");
		Matcher matcher=pattern.matcher(String.valueOf(product_code));
		return matcher.matches();
	}
	public boolean validateQuantity(int quantity)
	{
		return quantity>0;
	}
	
}
