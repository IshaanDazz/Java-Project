package com.capgemini.salesmanagement.dao;

import com.capgemini.salesmanagement.bean.ProductBean;

public class ProductDao implements IPoductDao {

	@Override
	public ProductBean getProductDetails(int productCode) {
		
		return null;
	}

	@Override
	public boolean insertSalesDetails(ProductBean productBean) {
		
		return false;
	}

}
