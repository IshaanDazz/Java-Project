package com.capgemini.salesmanagement.util;

public class DBConnection {

}
