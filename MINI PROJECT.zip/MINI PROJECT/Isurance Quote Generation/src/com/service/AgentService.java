package com.service;

import java.io.IOException;
import java.sql.SQLException;

import com.bean.AgentBean;
import com.bean.AgentViewPolicyBean;
import com.exception.AgentException;

public interface AgentService {

	public String accountCreation(AgentBean agentBean) throws AgentException, SQLException, IOException;
	AgentViewPolicyBean getPolicyDetails(String agentName) throws AgentException, SQLException, IOException ;
}
