package com.exception;

public class AgentException extends Exception{

	public AgentException(String message) 
	{
		
		super(message);
	}
}
