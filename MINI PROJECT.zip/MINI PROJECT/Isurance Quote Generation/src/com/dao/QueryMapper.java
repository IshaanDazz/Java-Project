package com.dao;

public interface QueryMapper {

	String FIND_AGENT_NAME = "Select username from create_profile where username=?";
	String INSERT_QUERY = "INSERT INTO agent_create_account VALUES(?,?,?,?,?,?,?,?)";
	String VIEW_POLICY_DETAILS_QUERY = "Select insuredName,policyNumber,policyPremimum,accountNumber from view_policy where agentName=?";

}
